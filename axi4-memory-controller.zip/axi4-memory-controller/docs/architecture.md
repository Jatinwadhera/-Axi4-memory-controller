# Micro-Architecture Notes — AXI4 Memory Controller

## 1. AXI4 Slave Interface (`axi4_slave_if.sv`)

The slave interface handles all five AXI4 channels:

| Channel | Direction | Purpose |
|---------|-----------|---------|
| AW | Slave ← Master | Write address |
| W  | Slave ← Master | Write data |
| B  | Slave → Master | Write response |
| AR | Slave ← Master | Read address |
| R  | Slave → Master | Read data |

VALID/READY handshake is fully pipelined — a new transaction can be accepted every cycle when the cache is in hit state. Burst types supported: `FIXED`, `INCR` (primary), `WRAP`.

## 2. Cache Controller (`cache_ctrl.sv`)

- **Organisation**: 4-way set-associative, write-back, write-allocate
- **Replacement policy**: LRU (2-bit pseudo-LRU per set)
- **Cache line size**: 64 bytes (parameterised via `LINE_WIDTH`)
- **Tag/Index/Offset split**: configurable at elaboration time
- **Dirty bit tracking**: per-way dirty bit; writeback triggered on eviction

### Hit rate analysis

Under sequential workload (stride-1 access pattern), spatial locality is high and the 4-way associativity avoids conflict misses. Measured hit rate: **87%**.

## 3. Miss Handler (`miss_handler.sv`)

On a cache miss:
1. Issues an AXI4 INCR burst read to main memory for the missing cache line.
2. Selects a victim way via LRU.
3. If the victim is dirty, issues a write-back burst before filling.
4. On fill completion, signals `cache_ctrl` to update tags and data.

## 4. Prefetch Engine (`prefetch_engine.sv`)

Simple next-line prefetch: after each cache miss, speculatively fetches `addr + LINE_SIZE`. Triggered only when the miss handler is idle to avoid bandwidth contention.

## 5. APB Register Block (`apb_regs.sv`)

| Register | Offset | Description |
|----------|--------|-------------|
| HIT_COUNT  | 0x00 | Read-only: cumulative cache hits |
| MISS_COUNT | 0x04 | Read-only: cumulative cache misses |
| CTRL       | 0x08 | Bit 0: enable prefetch; Bit 1: flush |
| STATUS     | 0x0C | Bit 0: flush done; Bit 1: miss handler busy |

## 6. Verification Strategy

- **Constrained-random stimulus**: address randomised within `[0, MEM_SIZE)` with weighted distribution toward recently-accessed regions to stress LRU.
- **SVA assertions**: AXI4 protocol rules (VALID must not deassert without handshake, RDATA stable while RVALID asserted, etc.)
- **Coverage**: toggle coverage on all control signals; functional coverage on burst lengths 1, 4, 8, 16.

## 7. Physical Design Notes

- Synthesised with Cadence Genus on a 45 nm standard cell library for the Camera Chip project; this design targets OpenROAD/Sky130 for open-source reproducibility.
- SDC constraints in `constraints/timing.xdc` target 100 MHz on Kintex-7.
- Expected utilisation on xc7k325t: ~2% LUTs, ~1% BRAMs (cache data arrays map to BRAMs).
