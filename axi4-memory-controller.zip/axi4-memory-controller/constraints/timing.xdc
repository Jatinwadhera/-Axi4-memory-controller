# ============================================================
# timing.xdc — SDC/XDC Timing Constraints
# Target: xc7k325tffg900-2 (Kintex-7)
# AXI4 Memory Controller with Adaptive Cache
# ============================================================

# --- Primary Clock ---
create_clock -period 10.000 -name aclk -waveform {0.000 5.000} [get_ports aclk]

# --- APB Clock (if separate) ---
# create_clock -period 20.000 -name pclk -waveform {0.000 10.000} [get_ports pclk]

# --- Input / Output Delays ---
set_input_delay  -clock aclk -max 2.0 [all_inputs]
set_input_delay  -clock aclk -min 0.5 [all_inputs]
set_output_delay -clock aclk -max 2.0 [all_outputs]
set_output_delay -clock aclk -min 0.5 [all_outputs]

# --- False Paths ---
set_false_path -from [get_ports aresetn]

# --- Multicycle Paths (APB register readback, non-timing-critical) ---
# set_multicycle_path -setup 2 -from [get_cells apb_regs_i/*] -to [get_cells *]

# --- Clock Groups (if CDC exists) ---
# set_clock_groups -asynchronous -group [get_clocks aclk] -group [get_clocks pclk]
