#!/usr/bin/env bash
# ============================================================
# openroad_flow.sh — RTL-to-GDS using OpenROAD + Sky130 PDK
# AXI4 Memory Controller with Adaptive Cache
# Jatin Wadhera | github.com/JatinWadhera
# ============================================================
# Prerequisites:
#   - OpenROAD installed and on PATH
#   - Yosys installed and on PATH
#   - Sky130 PDK at $SKY130_PDK (e.g. /path/to/skywater-pdk)
#   - OpenROAD-flow-scripts cloned alongside this repo
# ============================================================

set -e

DESIGN=axi4_mem_ctrl_top
PLATFORM=sky130hd
PDK=${SKY130_PDK:-"/opt/skywater-pdk"}
FLOW_DIR="../../OpenROAD-flow-scripts/flow"

echo "=== Step 1: Synthesis (Yosys) ==="
yosys -p "
  read_verilog -sv ../rtl/apb_regs.sv
  read_verilog -sv ../rtl/axi4_slave_if.sv
  read_verilog -sv ../rtl/cache_ctrl.sv
  read_verilog -sv ../rtl/miss_handler.sv
  read_verilog -sv ../rtl/prefetch_engine.sv
  read_verilog -sv ../rtl/axi4_mem_ctrl_top.sv
  synth -top ${DESIGN} -flatten
  dfflibmap -liberty ${PDK}/libraries/sky130_fd_sc_hd/latest/timing/sky130_fd_sc_hd__tt_025C_1v80.lib
  abc -liberty ${PDK}/libraries/sky130_fd_sc_hd/latest/timing/sky130_fd_sc_hd__tt_025C_1v80.lib
  write_verilog -noattr synth/${DESIGN}_synth.v
"

echo "=== Step 2: Floorplan ==="
openroad -exit << 'EOF'
read_lef $env(PDK)/libraries/sky130_fd_sc_hd/latest/tech/sky130_fd_sc_hd.tlef
read_lef $env(PDK)/libraries/sky130_fd_sc_hd/latest/lef/sky130_fd_sc_hd.lef
read_verilog synth/axi4_mem_ctrl_top_synth.v
link_design axi4_mem_ctrl_top
read_sdc ../constraints/timing.xdc
initialize_floorplan -utilization 40 -aspect_ratio 1.0 \
    -core_space 10 -site unithd
place_pins -random
EOF

echo "=== Step 3: Placement ==="
openroad -exit << 'EOF'
global_placement -density 0.6
detailed_placement
EOF

echo "=== Step 4: CTS ==="
openroad -exit << 'EOF'
clock_tree_synthesis -root_buf sky130_fd_sc_hd__clkbuf_16 \
    -buf_list sky130_fd_sc_hd__clkbuf_4
EOF

echo "=== Step 5: Routing ==="
openroad -exit << 'EOF'
global_route
detailed_route
EOF

echo "=== Step 6: DRC Check ==="
openroad -exit << 'EOF'
check_drc
write_def output/${DESIGN}_final.def
EOF

echo "=== Flow Complete — check output/${DESIGN}_final.def ==="
