# ============================================================
# run_sim.tcl — Vivado XSIM simulation script
# AXI4 Memory Controller with Adaptive Cache
# Jatin Wadhera | github.com/JatinWadhera
# ============================================================

# Open project
open_project ../pro_axi.xpr

# Set active simulation set
set_property -name "target_simulator" -value "XSim" -objects [current_project]
set_property -name "top" -value "tb_axi4_mem_ctrl" -objects [get_filesets sim_1]
set_property -name "top_lib" -value "xil_defaultlib" -objects [get_filesets sim_1]

# Launch simulation
launch_simulation

# Run for enough time to complete all test cases
run 10 us

# Check pass/fail via assertion count (SVA-based)
report_property [get_objects /tb_axi4_mem_ctrl/pass_count]
report_property [get_objects /tb_axi4_mem_ctrl/fail_count]

# Close
close_sim
