# ============================================================
# synth.tcl — Vivado synthesis + implementation script
# AXI4 Memory Controller with Adaptive Cache
# Jatin Wadhera | github.com/JatinWadhera
# ============================================================

open_project ../pro_axi.xpr

# Synthesis
launch_runs synth_1 -jobs 4
wait_on_run synth_1

if {[get_property PROGRESS [get_runs synth_1]] != "100%"} {
    error "Synthesis failed"
}

# Implementation
launch_runs impl_1 -to_step write_bitstream -jobs 4
wait_on_run impl_1

if {[get_property PROGRESS [get_runs impl_1]] != "100%"} {
    error "Implementation failed"
}

# Reports
open_run impl_1
report_timing_summary -file timing_summary.rpt
report_utilization   -file utilization.rpt
report_power         -file power.rpt

puts "Synthesis and implementation complete."
close_project
